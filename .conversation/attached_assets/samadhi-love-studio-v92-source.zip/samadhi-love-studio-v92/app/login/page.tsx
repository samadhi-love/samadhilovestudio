import { chatGPTSignInPath } from "../chatgpt-auth";
import { studioAccess } from "../studio-access";
export const dynamic = "force-dynamic";
export default async function LoginPage() {
  const access = await studioAccess();
  return <main className="member-shell member-login"><a className="brand" href="/community"><img src="/favicon.svg" alt=""/><strong>SAMADHI LOVE</strong></a><section className="member-login-card"><p className="eyebrow">MEMBER LOGIN</p><h1>Welcome to your<br/>creative home.</h1><p>One account for your private songs, recordings, videos and membership.</p>{access.id ? <a className="primary" href="/members">Continue to my account</a> : <a className="primary" target="_top" href={chatGPTSignInPath("/members")}>Continue with ChatGPT</a>}<p className="muted">Secure sign-in is provided by ChatGPT on this hosted Studio. No separate SAMADHI password is created or stored.</p><div className="actions"><a href="/members">Create a free member account</a><a href="/plans">Compare plans</a></div><a href="/community">Keep listening without an account</a></section></main>;
}
