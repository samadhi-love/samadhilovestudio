import { managedAvailable, ensureCreditAccount } from "../../../credits/account-ledger";
import { privateWorkspace } from "../../../studio-access";
import { privateHeaders } from "../store";
import { testElevenLabs } from "./provider";
import { keyStatus, removeElevenLabsKey, resolveElevenLabsKey, saveElevenLabsKey, validElevenLabsKey } from "./vault";

export const dynamic = "force-dynamic";
const options = { headers: privateHeaders };

function problem(error: string, status: number) {
  return Response.json({ error }, { ...options, status });
}

export async function GET() {
  const id = (await privateWorkspace())?.id;
  if (!id) return problem("Sign in to your creator workspace.", 401);
  try {
    if (managedAvailable()) {
      const account = await ensureCreditAccount(id);
      if (account.funding === "studio" && ["beta", "active"].includes(account.status) && account.period_end > Date.now())
        return Response.json({ available:true, saved:true, defaultProvider:true, connection:"connected", musicAccess:"available", managed:true,
          accountMessage:"Studio-funded production is configured. Credits are checked before processing." }, options);
    }
    return Response.json((await keyStatus(id)).status, options);
  }
  catch { return problem("Studio could not access its encrypted key store. Reload and try again.", 503); }
}

async function manageConnection(request: Request) {
  const id = (await privateWorkspace())?.id;
  if (!id) return problem("Sign in to your creator workspace.", 401);
  if (request.headers.get("origin") !== new URL(request.url).origin)
    return problem("Open the studio directly to manage your key.", 403);

  try {
    const { status, etag } = await keyStatus(id);
    if (request.method === "DELETE") {
      if (!await removeElevenLabsKey(id)) return problem("The secure credential store is unavailable.", 503);
      return Response.json((await keyStatus(id)).status, options);
    }
    if (!status.available) return problem("The secure credential store is unavailable. Try again later.", 503);

    if (request.method === "PUT") {
      const raw = await request.text();
      if (raw.length > 1024) return problem("Check the API key and try again.", 413);
      let input;
      try { input = JSON.parse(raw); } catch { return problem("Enter an ElevenLabs API key.", 400); }
      const key = typeof input?.apiKey === "string" ? input.apiKey.trim() : "";
      if (!validElevenLabsKey(key) || /^(?:ELEVENLABS_API_KEY=|["'])/.test(key))
        return problem("Paste only the ElevenLabs API key, without a variable name, quotes, or spaces.", 400);
      const check = await testElevenLabs(key);
      if (check.connection !== "connected") return problem([
        "The new key was not saved.", "Subscription check: " + check.accountMessage, "Music check: " + check.musicMessage,
      ].join(" "), 422);
      const defaultProvider = status.defaultProvider && check.musicAccess === "available";
      if (!await saveElevenLabsKey(id, key, check, defaultProvider, etag))
        return problem("Connection settings changed in another tab. Reload and try again.", 409);
      return Response.json({ ...status, saved: true, defaultProvider, ...check }, options);
    }

    let key: string | null;
    try { key = await resolveElevenLabsKey(id); }
    catch { return problem("Studio could not decrypt the saved key. Try again, or choose Reconnect to verify and replace it.", 503); }
    if (!key) return problem("Studio has no usable saved key. Connect your ElevenLabs account or use Reconnect to replace the key.", 400);
    const checking = request.method === "POST";
    const check = checking ? await testElevenLabs(key) : status;
    if (!checking && (status.connection !== "connected" || status.musicAccess !== "available"))
      return problem("Pass Test Connection before setting ElevenLabs as the default.", 422);
    if (!await saveElevenLabsKey(id, key, check, checking ? status.defaultProvider : true, etag))
      return problem("Connection settings changed in another tab. Reload and try again.", 409);
    return Response.json({ ...status, ...check, defaultProvider: checking ? status.defaultProvider : true }, options);
  } catch {
    return problem("Could not manage the ElevenLabs connection. Try again.", 503);
  }
}

export const PUT = manageConnection;
export const POST = manageConnection;
export const PATCH = manageConnection;
export const DELETE = manageConnection;
